export { default } from './FuseSuspense';
