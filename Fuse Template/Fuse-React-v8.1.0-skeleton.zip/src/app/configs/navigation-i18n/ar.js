const locale = {
  APPLICATIONS: 'تطبيقات',
  EXAMPLE: 'مثال',
};

export default locale;
